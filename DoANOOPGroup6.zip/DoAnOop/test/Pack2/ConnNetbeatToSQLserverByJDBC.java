package Pack2;

import java.sql.*;


public class ConnNetbeatToSQLserverByJDBC {


public static void main(String[] args) {
      String dbURL = "jdbc:sqlserver://DESKTOP-IVN453T\\SQLEXPRESS;databaseName=test;encrypt=false";
      String username = "sa";
      String password = "123";

      try {
         // Load the SQL Server JDBC driver
         Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

         // Create a connection to the database
         Connection conn = DriverManager.getConnection(dbURL, username, password);

         // Execute a query
         Statement statement = conn.createStatement();
         ResultSet resultSet = statement.executeQuery("SELECT * FROM NhanVien JOIN ChucVu ON NhanVien.tenChucVu = ChucVu.tenChucVu");

         // Process the results
         while (resultSet.next()) {
            System.out.println(resultSet.getString("idNV") + "\t" + resultSet.getString("mkNV") + "\t" + resultSet.getDouble("heSoLuong"));
         }

         // Close the connection and resources
         resultSet.close();
         statement.close();
         conn.close();

      } catch (Exception e) {
         e.printStackTrace();
      }
   } 
}
