package Pack2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SQLServerConnectionExample {
    public static void main(String[] args) {
        String url = "jdbc:sqlserver://LAPTOP-TEP72O3K;databaseName=QuanLyNV;encrypt=false";
        String username = "sa";
        String password = "123456";

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            // Connection established successfully
            System.out.println("Connected to the SQL Server database!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}