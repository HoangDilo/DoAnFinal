/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author THANH
 */
public class DBconnect {

    public Connection conn;
    String url = "jdbc:sqlserver://trai4chet2tlqserver.id.vn;databaseName=QuanLyNV;encrypt=false";
    //String url = "jdbc:sqlserver://LAPTOP-TEP72O3K;databaseName=QuanLyNVPRO;encrypt=false";
    String user = "sa";
    String password = "thanh";
    //String password = "123456";

    public Connection Connect() {
        try {
            //Class.forName("com.mysql.cj.jdbc.Driver");
            this.conn = DriverManager.getConnection(this.url, this.user, this.password);
            //ClassNotFoundException | 
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return this.conn;
    }
   
}
