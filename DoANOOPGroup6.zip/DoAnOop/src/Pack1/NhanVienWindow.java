/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Pack1;

import Classes.ChamCong;
import Classes.NhanVien;
import DAO.DBconnect;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.table.*;

/**
 *
 * @author HOANG DILO
 */
public class NhanVienWindow extends javax.swing.JFrame {
    ChatTong ct;
    private String idnhanvien;
    private static DBconnect dbcn = new DBconnect();
    private static Connection conn = dbcn.Connect();
    NhanVien nv = new NhanVien();
    ChamCong cc = new ChamCong();


    /**
     * Creates new form NhanVienWindow
     *
     * @param idnhanvien
     */
    public NhanVienWindow(String idnhanvien) {
        initComponents();
        setLocationRelativeTo(null);
        this.idnhanvien = idnhanvien;
        
        //tao 1 model combo box de select years
        DefaultComboBoxModel<String> md = new DefaultComboBoxModel<>();
        for (int i = 2000; i<=2100; i++) {
            md.addElement("Năm " + i);
        }
        this.jComboBoxNam.setModel(md);
        
        this.display();
        this.displayTable();
        this.isChamCong();
    }

    public void display() {
        LocalDate ld = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        this.labelNgayThangNam.setText(ld.format(formatter));
        
        this.ComboBoxChonThang.setSelectedIndex(ld.getMonthValue() - 1);
        this.jComboBoxNam.setSelectedIndex(ld.getYear() - 2000);
        
        try {
            PreparedStatement pstmt = conn.prepareStatement("Select * from NhanVien LEFT OUTER JOIN PhongBan ON NhanVien.idPhongBan = PhongBan.idPhongBan "
                    + "LEFT OUTER JOIN DuAn ON NhanVien.idDuAn = DuAn.idDuAn LEFT OUTER JOIN Nhom ON NhanVien.idNhom = Nhom.idNhom where idNV = ?");

            pstmt.setString(1, getIdnhanvien());
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                
                this.txtIdNV.setText(rs.getString("idNV"));
                this.txtTenNV.setText(rs.getString("tenNV"));
                this.txtChucVu.setText(rs.getString("tenChucVu"));
                this.txtEmail.setText(rs.getString("emailNV"));
                this.txtCCCD.setText(rs.getString("CCCD"));
                if(rs.getBoolean("gioiTinhNV") != true) this.txtGioiTinh.setText("Nữ");
                else {
                    this.txtGioiTinh.setText("Nam");
                }
                this.txtEmail.setText(rs.getString("emailNV"));
                //chuyen doi Date trong SQL sang String de in ra man hinh
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");               
                this.txtDoB.setText(sdf.format(rs.getDate("ngaySinhNV")));
                
                this.txtPhoneNumber.setText(rs.getString("sdtNV"));
                if(rs.getString("tenPhongBan") == null) {
                    this.txtPB.setText("Không có");
                }
                else this.txtPB.setText(rs.getString("tenPhongBan"));
                
                if(rs.getString("tenDuAn") == null) {
                    this.txtDA.setText("Không có");
                }
                else this.txtDA.setText(rs.getString("tenDuAn"));
                
                if(rs.getString("tenNhom") == null) {
                    this.txtN.setText("Không có");
                }
                else this.txtN.setText(rs.getString("tenNhom"));
                
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void displayTable() {
        
        try {
            
            Statement state = conn.createStatement();
            
            ResultSet rs2;
            rs2 = state.executeQuery("select idChamCong, CaLam.tenCaLam, timeChamCong from ChamCong join CaLam on ChamCong.tenCaLam = CaLam.tenCaLam join NhanVien on NhanVien.idNV = ChamCong.idNV\n" +
                    "where NhanVien.idNV = '" + this.getIdnhanvien() + "' and MONTH(ChamCong.timeChamCong) = " + (ComboBoxChonThang.getSelectedIndex() + 1) + " and YEAR(ChamCong.timeChamCong) = " + (jComboBoxNam.getSelectedIndex() + 2000) +" ");
            
            DefaultTableModel tbm = (DefaultTableModel) this.jTable1.getModel();
            
            tbm.setRowCount(0);
            SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss dd-MM-yyyy");
            
            while(rs2.next()) {
                tbm.addRow(new Object[] {rs2.getString("idChamCong"), rs2.getString("tenCaLam"), formatter.format(rs2.getTimestamp("timeChamCong")) } );
                
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void isChamCong() {
        try {

            Statement st = conn.createStatement();
            
            ResultSet r = st.executeQuery("select count(idChamCong) AS SL from ChamCong "
                    + "where idNV = '" + this.getIdnhanvien() + "' AND YEAR(timeChamCong) = YEAR(GETDATE()) AND MONTH(timeChamCong) = MONTH(GETDATE()) AND DAY(timeChamCong) = DAY(GETDATE())"
                    + "group by idNV");
            if (r.next()) {
                if(r.getInt("SL") == 0) {
                    this.ThongbaoChamCong.setText("Bạn CHƯA  chấm công!");
                }
                else {
                    this.ThongbaoChamCong.setText("Bạn ĐÃ       chấm công!");
                }
                
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public String getIdnhanvien() {
        return idnhanvien;
    }

    public void setIdnhanvien(String idnhanvien) {
        this.idnhanvien = idnhanvien;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        labelMSNV = new javax.swing.JLabel();
        txtEmail = new javax.swing.JLabel();
        labelTenNhanVien1 = new javax.swing.JLabel();
        txtIdNV = new javax.swing.JLabel();
        labelTenNhanVien2 = new javax.swing.JLabel();
        txtChucVu = new javax.swing.JLabel();
        labelTenNhanVien3 = new javax.swing.JLabel();
        txtTenNV = new javax.swing.JLabel();
        labelTenNhanVien4 = new javax.swing.JLabel();
        labelTenNhanVien5 = new javax.swing.JLabel();
        labelTenNhanVien6 = new javax.swing.JLabel();
        labelTenNhanVien7 = new javax.swing.JLabel();
        txtN = new javax.swing.JLabel();
        txtDoB = new javax.swing.JLabel();
        txtGioiTinh = new javax.swing.JLabel();
        txtPhoneNumber = new javax.swing.JLabel();
        labelTenNhanVien8 = new javax.swing.JLabel();
        labelTenNhanVien9 = new javax.swing.JLabel();
        labelTenNhanVien10 = new javax.swing.JLabel();
        txtCCCD = new javax.swing.JLabel();
        txtPB = new javax.swing.JLabel();
        txtDA = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        labelChonThang = new javax.swing.JLabel();
        ThongbaoChamCong = new javax.swing.JLabel();
        jComboBoxNam = new javax.swing.JComboBox<>();
        labelChonThang1 = new javax.swing.JLabel();
        ComboBoxChonThang = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        labelDuLieuChamCong2 = new javax.swing.JLabel();
        labelHomNayLa1 = new javax.swing.JLabel();
        labelNgayThangNam = new javax.swing.JLabel();
        windowBackground = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Thông tin nhân viên");
        setMinimumSize(new java.awt.Dimension(600, 400));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(1280, 720));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pack1/profilepicture.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 50, 96, 96));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setForeground(new java.awt.Color(204, 204, 204));
        jPanel2.setOpaque(false);
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        labelMSNV.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        labelMSNV.setForeground(new java.awt.Color(102, 102, 102));
        labelMSNV.setText("Mã số nhân viên:");
        jPanel2.add(labelMSNV, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        txtEmail.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        txtEmail.setText("jlabel3");
        jPanel2.add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 130, 290, -1));

        labelTenNhanVien1.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        labelTenNhanVien1.setForeground(new java.awt.Color(102, 102, 102));
        labelTenNhanVien1.setText("Email:");
        jPanel2.add(labelTenNhanVien1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 130, -1, -1));

        txtIdNV.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        txtIdNV.setText("jlabel3");
        jPanel2.add(txtIdNV, new org.netbeans.lib.awtextra.AbsoluteConstraints(167, 10, 130, -1));

        labelTenNhanVien2.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        labelTenNhanVien2.setForeground(new java.awt.Color(102, 102, 102));
        labelTenNhanVien2.setText("Chức vụ:");
        jPanel2.add(labelTenNhanVien2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, -1, -1));

        txtChucVu.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        txtChucVu.setText("jlabel3");
        jPanel2.add(txtChucVu, new org.netbeans.lib.awtextra.AbsoluteConstraints(99, 70, 150, -1));

        labelTenNhanVien3.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        labelTenNhanVien3.setForeground(new java.awt.Color(102, 102, 102));
        labelTenNhanVien3.setText("Tên nhân viên:");
        jPanel2.add(labelTenNhanVien3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, -1, -1));

        txtTenNV.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        txtTenNV.setText("jlabel3");
        jPanel2.add(txtTenNV, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 40, 150, -1));

        labelTenNhanVien4.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        labelTenNhanVien4.setForeground(new java.awt.Color(102, 102, 102));
        labelTenNhanVien4.setText("Nhóm:");
        jPanel2.add(labelTenNhanVien4, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 70, -1, -1));

        labelTenNhanVien5.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        labelTenNhanVien5.setForeground(new java.awt.Color(102, 102, 102));
        labelTenNhanVien5.setText("Ngày sinh:");
        jPanel2.add(labelTenNhanVien5, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 40, -1, -1));

        labelTenNhanVien6.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        labelTenNhanVien6.setForeground(new java.awt.Color(102, 102, 102));
        labelTenNhanVien6.setText("Giới tính:");
        jPanel2.add(labelTenNhanVien6, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 70, -1, -1));

        labelTenNhanVien7.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        labelTenNhanVien7.setForeground(new java.awt.Color(102, 102, 102));
        labelTenNhanVien7.setText("Số điện thoại:");
        jPanel2.add(labelTenNhanVien7, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 100, -1, -1));

        txtN.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        txtN.setText("jlabel3");
        jPanel2.add(txtN, new org.netbeans.lib.awtextra.AbsoluteConstraints(735, 70, 150, -1));

        txtDoB.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        txtDoB.setText("jlabel3");
        jPanel2.add(txtDoB, new org.netbeans.lib.awtextra.AbsoluteConstraints(442, 40, 150, -1));

        txtGioiTinh.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        txtGioiTinh.setText("jlabel3");
        jPanel2.add(txtGioiTinh, new org.netbeans.lib.awtextra.AbsoluteConstraints(431, 70, 150, -1));

        txtPhoneNumber.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        txtPhoneNumber.setText("jlabel3");
        jPanel2.add(txtPhoneNumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(471, 100, 150, -1));

        labelTenNhanVien8.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        labelTenNhanVien8.setForeground(new java.awt.Color(102, 102, 102));
        labelTenNhanVien8.setText("CCCD/ CMND:");
        jPanel2.add(labelTenNhanVien8, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 10, -1, -1));

        labelTenNhanVien9.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        labelTenNhanVien9.setForeground(new java.awt.Color(102, 102, 102));
        labelTenNhanVien9.setText("Phòng ban:");
        jPanel2.add(labelTenNhanVien9, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 10, -1, -1));

        labelTenNhanVien10.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        labelTenNhanVien10.setForeground(new java.awt.Color(102, 102, 102));
        labelTenNhanVien10.setText("Dự án:");
        jPanel2.add(labelTenNhanVien10, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 40, -1, -1));

        txtCCCD.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        txtCCCD.setText("jlabel3");
        jPanel2.add(txtCCCD, new org.netbeans.lib.awtextra.AbsoluteConstraints(472, 10, 150, -1));

        txtPB.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        txtPB.setText("jlabel3");
        jPanel2.add(txtPB, new org.netbeans.lib.awtextra.AbsoluteConstraints(778, 10, 210, -1));

        txtDA.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        txtDA.setText("jlabel3");
        jPanel2.add(txtDA, new org.netbeans.lib.awtextra.AbsoluteConstraints(735, 40, 150, -1));

        jButton2.setText("Đăng xuất");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(856, 130, 130, -1));

        jButton4.setText("Mở Chat");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(856, 90, 130, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 50, 990, 160));

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        jPanel4.setBackground(new java.awt.Color(204, 204, 204));

        jScrollPane2.setToolTipText("");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Chấm công", "Ca làm", "Thời gian chấm công"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.setRowHeight(30);
        jTable1.getTableHeader().setReorderingAllowed(false);
        jScrollPane2.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
        }

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 16, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );

        jScrollPane1.setViewportView(jPanel4);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 300, 1125, 280));

        labelChonThang.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        labelChonThang.setText("Chọn Năm:");
        jPanel1.add(labelChonThang, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 270, -1, -1));

        ThongbaoChamCong.setFont(new java.awt.Font("Arial", 3, 16)); // NOI18N
        ThongbaoChamCong.setForeground(new java.awt.Color(255, 255, 255));
        ThongbaoChamCong.setText("Bạn CHƯA  chấm công!");
        jPanel1.add(ThongbaoChamCong, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 600, -1, -1));

        jComboBoxNam.setMaximumRowCount(6);
        jComboBoxNam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxNamActionPerformed(evt);
            }
        });
        jPanel1.add(jComboBoxNam, new org.netbeans.lib.awtextra.AbsoluteConstraints(1033, 270, 100, -1));

        labelChonThang1.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        labelChonThang1.setText("Chọn Tháng:");
        jPanel1.add(labelChonThang1, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 270, -1, -1));

        ComboBoxChonThang.setMaximumRowCount(6);
        ComboBoxChonThang.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4", "Tháng 5", "Tháng 6", "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11", "Tháng 12" }));
        jPanel1.add(ComboBoxChonThang, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 270, 100, -1));

        jButton1.setText("Reset");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 270, 60, -1));

        jButton3.setText("Đổi mật khẩu");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 180, 120, -1));

        labelDuLieuChamCong2.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        labelDuLieuChamCong2.setText("Dữ liệu chấm công của bạn:");
        jPanel1.add(labelDuLieuChamCong2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 270, -1, -1));

        labelHomNayLa1.setFont(new java.awt.Font("Arial", 3, 18)); // NOI18N
        labelHomNayLa1.setText("Hôm nay là:");
        jPanel1.add(labelHomNayLa1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 600, -1, -1));

        labelNgayThangNam.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        labelNgayThangNam.setText("dd-MM-yyyy");
        jPanel1.add(labelNgayThangNam, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 600, -1, -1));

        windowBackground.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pack1/nhanVienWindowBackground.png"))); // NOI18N
        windowBackground.setText("jLabel1");
        jPanel1.add(windowBackground, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 720));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBoxNamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxNamActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxNamActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.displayTable();
        this.isChamCong();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        new DoiMatKhau(this.getIdnhanvien()).setVisible(true);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        ct.dispose();
        this.dispose();
        new DangNhapNhanVien().setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        ct = new ChatTong(this.getIdnhanvien());
        ct.setVisible(true);
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> ComboBoxChonThang;
    private javax.swing.JLabel ThongbaoChamCong;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JComboBox<String> jComboBoxNam;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel labelChonThang;
    private javax.swing.JLabel labelChonThang1;
    private javax.swing.JLabel labelDuLieuChamCong2;
    private javax.swing.JLabel labelHomNayLa1;
    private javax.swing.JLabel labelMSNV;
    private javax.swing.JLabel labelNgayThangNam;
    private javax.swing.JLabel labelTenNhanVien1;
    private javax.swing.JLabel labelTenNhanVien10;
    private javax.swing.JLabel labelTenNhanVien2;
    private javax.swing.JLabel labelTenNhanVien3;
    private javax.swing.JLabel labelTenNhanVien4;
    private javax.swing.JLabel labelTenNhanVien5;
    private javax.swing.JLabel labelTenNhanVien6;
    private javax.swing.JLabel labelTenNhanVien7;
    private javax.swing.JLabel labelTenNhanVien8;
    private javax.swing.JLabel labelTenNhanVien9;
    private javax.swing.JLabel txtCCCD;
    private javax.swing.JLabel txtChucVu;
    private javax.swing.JLabel txtDA;
    private javax.swing.JLabel txtDoB;
    private javax.swing.JLabel txtEmail;
    private javax.swing.JLabel txtGioiTinh;
    private javax.swing.JLabel txtIdNV;
    private javax.swing.JLabel txtN;
    private javax.swing.JLabel txtPB;
    private javax.swing.JLabel txtPhoneNumber;
    private javax.swing.JLabel txtTenNV;
    private javax.swing.JLabel windowBackground;
    // End of variables declaration//GEN-END:variables
}
