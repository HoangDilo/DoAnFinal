/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Pack1;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.Year;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

import DAO.DBconnect;
/**
 *
 * @author Hoang Anh IT
 */
public class QLTaiChinh extends javax.swing.JFrame {
    
    /**
     * Creates new form QLTaiChinh
     */
    
    private static DBconnect dbcn = new DBconnect();
    private static Connection conn = dbcn.Connect();
    
    
    public QLTaiChinh() {
        initComponents(); 
        setLocationRelativeTo(null);
        int YearHT = Year.now().getValue();
        YearSpinner.setValue(YearHT);
        jTable2.getColumnModel().getColumn(0).setHeaderValue("Lương "+ MonthCombo.getSelectedItem() + "/" + YearHT);
        show_thongTin_nv();
        //show_Thuong_nv();
        show_kpi_cu();
        show_thuong_cu();
        
    }
    
    public void show_thongTin_nv(){
        try {
            Statement statement = conn.createStatement();
            String sqlQuery = "SELECT NhanVien.idNV, NhanVien.tenNV, ChucVu.tenChucVu, ChucVu.heSoLuong, COUNT(ChamCong.idChamCong) AS SoChamCong\n" +
            "FROM NhanVien\n" +
            "LEFT JOIN ChamCong ON NhanVien.idNV = ChamCong.idNV AND MONTH(ChamCong.timeChamCong) = ? AND YEAR(ChamCong.timeChamCong) = ?\n" +
            "JOIN ChucVu ON NhanVien.tenChucVu = ChucVu.tenChucVu\n" +
            "GROUP BY NhanVien.idNV, NhanVien.tenNV, ChucVu.tenChucVu, ChucVu.heSoLuong";
            PreparedStatement pstm = conn.prepareStatement(sqlQuery);
            pstm.setInt(1, MonthCombo.getSelectedIndex()+1);
            pstm.setInt(2, (int)YearSpinner.getValue());
            ResultSet resultSet = pstm.executeQuery();
            
            String inRaQuery = "SELECT KPI FROM KPIvaThuong";
            ResultSet rst = statement.executeQuery(inRaQuery);
            int checkKPI = 0;
            if(rst.next()){
                checkKPI = rst.getInt("KPI");
            }
            
            String inRaQueryTH = "SELECT Thuong FROM KPIvaThuong";
            ResultSet rstTH = statement.executeQuery(inRaQueryTH);
            int Thuong = 0;
            if(rstTH.next()){
                Thuong = rstTH.getInt("Thuong");
            }
            
            String luongQuery = "SELECT luongCaLam FROM CaLam Where tenCaLam = 'Ca Sáng'";
            ResultSet rstLuong = statement.executeQuery(luongQuery);
            int LuongCung = 0;
            if(rstLuong.next()){
                LuongCung = rstLuong.getInt("luongCaLam");
            }

            // Retrieve the table model from the JTable JOIN ChucVu ON NhanVien.tenChucVu = ChucVu.tenChucVu
            DefaultTableModel tableModel = (DefaultTableModel) this.jTable1.getModel();
            DefaultTableModel tableModel1 = (DefaultTableModel) this.jTable3.getModel();
            DefaultTableModel tableModel2 = (DefaultTableModel) this.jTable2.getModel();
            
            /*tableModel.addColumn("idNV");
            tableModel.addColumn("tenNV");
            tableModel.addColumn("tenChucVu");
            tableModel.addColumn("heSoLuong");*/
            
            tableModel.setRowCount(0);
            tableModel1.setRowCount(0);
            tableModel2.setRowCount(0);
            
            int thuongg = 0;
            

            while (resultSet.next()) {
                String id = resultSet.getString("idNV");
                String name = resultSet.getString("tenNV");
                double heSoLuong = resultSet.getDouble("heSoLuong");
                String positionName = resultSet.getString("tenChucVu");
                int SoChamCong = resultSet.getInt("SoChamCong");
                
                if(SoChamCong >= checkKPI){
                    thuongg = Thuong;
                }else{
                    thuongg = 0;
                }
                tableModel1.addRow(new Object[]{thuongg});
                tableModel.addRow(new Object[]{id, name, positionName, heSoLuong, SoChamCong });
                tableModel2.addRow(new Object[]{LuongCung*heSoLuong*SoChamCong+thuongg});
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    
    public void show_Thuong_nv() {
        try {
            String sqlQuery = "SELECT NhanVien.idNV, NhanVien.tenNV, ChucVu.tenChucVu, ChucVu.heSoLuong, COUNT(ChamCong.idChamCong) AS SoChamCong\n" +
            "FROM NhanVien\n" +
            "LEFT JOIN ChamCong ON NhanVien.idNV = ChamCong.idNV AND MONTH(ChamCong.timeChamCong) = ? AND YEAR(ChamCong.timeChamCong) = ?\n" +
            "JOIN ChucVu ON NhanVien.tenChucVu = ChucVu.tenChucVu\n" +
            "GROUP BY NhanVien.idNV, NhanVien.tenNV, ChucVu.tenChucVu, ChucVu.heSoLuong";
            PreparedStatement pstm = conn.prepareStatement(sqlQuery);
            pstm.setInt(1, MonthCombo.getSelectedIndex()+1);
            pstm.setInt(2, (int)YearSpinner.getValue());
            ResultSet resultSet = pstm.executeQuery();
            
            

            // Retrieve the table model from the JTable
            //DefaultTableModel tableModel1 = (DefaultTableModel) this.jTable3.getModel();
            /*tableModel.addColumn("idNV");
            tableModel.addColumn("tenNV");
            tableModel.addColumn("tenChucVu");
            tableModel.addColumn("heSoLuong");*/
            
            //tableModel1.setRowCount(0);
            int thuong = 0;

            while (resultSet.next()) {
                //int SoChamCong = resultSet.getInt("SoChamCong");
                //int checkValue = Integer.parseInt(txt_KPI.getText());
                //if(SoChamCong >= checkValue){
                   // thuong = 5000000;
                //}
                //tableModel1.addRow(new Object[]{thuong});
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        YearSpinner = new javax.swing.JSpinner();
        MonthCombo = new javax.swing.JComboBox<>();
        jButton2 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        setKPI = new javax.swing.JTextField();
        button_setKPI = new javax.swing.JButton();
        setThuong = new javax.swing.JTextField();
        button_setThuong = new javax.swing.JButton();
        txt_KPI = new javax.swing.JLabel();
        txt_Thuong = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID ", "Tên", "Chức vụ", "HSL", "Số Chấm Công"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.setRowHeight(30);
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
            jTable1.getColumnModel().getColumn(3).setResizable(false);
        }

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 84, 850, 610));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Lương tháng n"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable2.setRowHeight(30);
        jScrollPane2.setViewportView(jTable2);
        if (jTable2.getColumnModel().getColumnCount() > 0) {
            jTable2.getColumnModel().getColumn(0).setResizable(false);
        }

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1013, 84, 250, 610));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Chọn tháng:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 6, -1, 30));
        getContentPane().add(YearSpinner, new org.netbeans.lib.awtextra.AbsoluteConstraints(1121, 7, 73, 30));

        MonthCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4", "Tháng 5", "Tháng 6", "Tháng 7", "Tháng 8 ", "Tháng 9", "Tháng 10", "Tháng 11", "Tháng 12" }));
        MonthCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MonthComboActionPerformed(evt);
            }
        });
        getContentPane().add(MonthCombo, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 7, 115, 30));

        jButton2.setText("Confirm");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1200, 7, -1, 30));

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Thưởng"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable3.setRowHeight(30);
        jScrollPane3.setViewportView(jTable3);
        if (jTable3.getColumnModel().getColumnCount() > 0) {
            jTable3.getColumnModel().getColumn(0).setResizable(false);
        }

        getContentPane().add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(877, 84, 130, 610));

        setKPI.setText("Set KPI Mới");
        setKPI.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                setKPIFocusGained(evt);
            }
        });
        getContentPane().add(setKPI, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 40, 130, 30));

        button_setKPI.setText("SET");
        button_setKPI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_setKPIActionPerformed(evt);
            }
        });
        getContentPane().add(button_setKPI, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 40, -1, 30));

        setThuong.setText("Set Thưởng Mới");
        setThuong.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                setThuongFocusGained(evt);
            }
        });
        getContentPane().add(setThuong, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 40, 130, 30));

        button_setThuong.setText("SET");
        button_setThuong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_setThuongActionPerformed(evt);
            }
        });
        getContentPane().add(button_setThuong, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 40, 70, 30));

        txt_KPI.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        txt_KPI.setForeground(new java.awt.Color(255, 255, 255));
        txt_KPI.setText("0000");
        getContentPane().add(txt_KPI, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 46, 40, 20));

        txt_Thuong.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        txt_Thuong.setForeground(new java.awt.Color(255, 255, 255));
        txt_Thuong.setText("0000");
        getContentPane().add(txt_Thuong, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 46, 80, 20));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("KPI hiện tại:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 46, -1, 20));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("VNĐ");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 46, 30, 20));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("ca/tháng");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 46, 90, 20));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Thưởng hiện tại:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 46, 100, 20));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pack1/quanLyTaiChinh.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 720));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MonthComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MonthComboActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_MonthComboActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        jTable2.getColumnModel().getColumn(0).setHeaderValue("Lương "+ MonthCombo.getSelectedItem() + "/" + YearSpinner.getValue());
        show_thongTin_nv();
        //show_Thuong_nv();
    }//GEN-LAST:event_jButton2ActionPerformed
    
    private void show_kpi_cu(){
        try{
            String inRaQuery = "SELECT KPI FROM KPIvaThuong";
            Statement stm = conn.createStatement();
            ResultSet rst = stm.executeQuery(inRaQuery);
            
            if(rst.next()){
                int showKPI = rst.getInt("KPI");
                this.txt_KPI.setText(String.valueOf(showKPI)) ;
            }
            
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    private void show_thuong_cu(){
        try{
            String inRaQuery = "SELECT Thuong FROM KPIvaThuong";
            Statement stm = conn.createStatement();
            ResultSet rst = stm.executeQuery(inRaQuery);
            
            if(rst.next()){
                int showThuong = rst.getInt("Thuong");
                this.txt_Thuong.setText(String.valueOf(showThuong)) ;
            }
            
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    private void button_setKPIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_setKPIActionPerformed
        
        // TODO add your handling code here:
        txt_KPI.setText(setKPI.getText()) ;
        int KPItoDB = Integer.parseInt(txt_KPI.getText());
        try{
            String sqlQuery = "UPDATE KPIvaThuong SET KPI = ? WHERE maGaming = 1";
            String inRaQuery ="SELECT KPI FROM KPIvaThuong";
            PreparedStatement pstm = conn.prepareStatement(sqlQuery);
            pstm.setInt(1, KPItoDB);
            int resultSet = pstm.executeUpdate();
            setKPI.setText("") ;
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
        
        
        
    }//GEN-LAST:event_button_setKPIActionPerformed

    private void button_setThuongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_setThuongActionPerformed
        // TODO add your handling code here:
        txt_Thuong.setText(setThuong.getText()) ;
        int ThuongtoDB = Integer.parseInt(txt_Thuong.getText());
        try{
            String sqlQuery = "UPDATE KPIvaThuong SET Thuong = ? WHERE maGaming = 1";
            PreparedStatement pstm = conn.prepareStatement(sqlQuery);
            pstm.setInt(1, ThuongtoDB);
            int resultSet = pstm.executeUpdate();
            
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_button_setThuongActionPerformed

    private void setKPIFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_setKPIFocusGained
        // TODO add your handling code here:
        this.setKPI.setText("");
    }//GEN-LAST:event_setKPIFocusGained

    private void setThuongFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_setThuongFocusGained
        // TODO add your handling code here:
        this.setThuong.setText("");
    }//GEN-LAST:event_setThuongFocusGained

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QLTaiChinh.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QLTaiChinh.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QLTaiChinh.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QLTaiChinh.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new QLTaiChinh().setVisible(true);
            }
        });
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> MonthCombo;
    private javax.swing.JSpinner YearSpinner;
    private javax.swing.JButton button_setKPI;
    private javax.swing.JButton button_setThuong;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTextField setKPI;
    private javax.swing.JTextField setThuong;
    private javax.swing.JLabel txt_KPI;
    private javax.swing.JLabel txt_Thuong;
    // End of variables declaration//GEN-END:variables
}
