/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Pack1;

import Classes.*;
import DAO.DBconnect;
import com.microsoft.sqlserver.jdbc.SQLServerException;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Admin
 */
public class QuanLyChung extends javax.swing.JFrame {

    private static DBconnect dbcn = new DBconnect();
    private static Connection conn = dbcn.Connect();

    /**
     * Creates new form QuanLyChung
     */
    public QuanLyChung() {
        initComponents();
        setLocationRelativeTo(null);
        show_all_nv();
        show_all_nhom();
        show_all_pb();
        show_all_duan();
        show_cham_cong();
        show_ngay_cc();
    }

    NhanVien nvOfQuanLyChung = new NhanVien();
    NhanVien nvChamCongOfQLChung = new NhanVien();
    Nhom nhomOfQuanLyChung = new Nhom();
    PhongBan pbOfQuanLyChung = new PhongBan();
    DuAn duanOfQuanLyChung = new DuAn();

    public void show_all_nhom() {
        try {

            Statement statement = conn.createStatement();
            String sqlQuery = "SELECT Nhom.idNhom, tenNhom , COUNT(idNV) AS soLuongNvNhom FROM Nhom LEFT OUTER JOIN NhanVien ON Nhom.idNhom = NhanVien.idNhom\n"
                    + "GROUP BY tenNhom, Nhom.idNhom";
            ResultSet resultSet = statement.executeQuery(sqlQuery);

            // Retrieve the table model from the JTable
            DefaultTableModel tableModel1 = (DefaultTableModel) this.Table_QLNhom.getModel();
            /*tableModel.addColumn("idNV");
            tableModel.addColumn("tenNV");
            tableModel.addColumn("tenChucVu");
            tableModel.addColumn("heSoLuong");*/

            tableModel1.setRowCount(0);

            while (resultSet.next()) {
                String id = resultSet.getString("idNhom");
                String name = resultSet.getString("tenNhom");
                int soLuong = resultSet.getInt("soLuongNvNhom");

                tableModel1.addRow(new Object[]{id, name, soLuong});
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void show_all_nv() {
        try {

            Statement statement = conn.createStatement();
            String sqlQuery = "SELECT * FROM NhanVien LEFT OUTER JOIN ChucVu ON NhanVien.tenChucVu = ChucVu.tenChucVu LEFT OUTER JOIN Nhom ON NhanVien.idNhom = Nhom.idNhom LEFT OUTER JOIN DuAn ON NhanVien.idDuAn = DuAn.idDuAn LEFT OUTER JOIN PhongBan ON NhanVien.idPhongBan = PhongBan.idPhongBan";
            ResultSet resultSet = statement.executeQuery(sqlQuery);

            // Retrieve the table model from the JTable
            DefaultTableModel tableModel1 = (DefaultTableModel) this.mainTable.getModel();
            /*tableModel.addColumn("idNV");
            tableModel.addColumn("tenNV");
            tableModel.addColumn("tenChucVu");
            tableModel.addColumn("heSoLuong");*/

            tableModel1.setRowCount(0);

            while (resultSet.next()) {
                String id = resultSet.getString("idNV");
                String name = resultSet.getString("tenNV");
                String cccd = resultSet.getString("CCCD");
                String ngaySinh = resultSet.getString("ngaySinhNV");
                String email = resultSet.getString("emailNV");
                String sdt = resultSet.getString("sdtNV");
                boolean gioiTinh = resultSet.getBoolean("gioiTinhNV");
                String nhom = resultSet.getString("tenNhom");
                String phongBan = resultSet.getString("tenPhongBan");
                String duAn = resultSet.getString("tenDuAn");
                String chucVu = resultSet.getString("tenChucVu");

                String gioiTinhString = "";

                if (gioiTinh) {
                    gioiTinhString = "Nam";
                } else {
                    gioiTinhString = "Nữ";
                }

                tableModel1.addRow(new Object[]{id, name, cccd, ngaySinh, gioiTinhString, sdt, email, chucVu, nhom, phongBan, duAn});
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void show_all_pb() {
        try {

            Statement statement = conn.createStatement();
            String sqlQuery = "SELECT PhongBan.idPhongBan, tenPhongBan, COUNT(idNV) AS soLuongNvPB FROM PhongBan LEFT OUTER JOIN NhanVien ON PhongBan.idPhongBan = NhanVien.idPhongBan\n"
                    + "GROUP BY tenPhongBan, PhongBan.idPhongBan";
            ResultSet resultSet = statement.executeQuery(sqlQuery);

            // Retrieve the table model from the JTable
            DefaultTableModel tableModel1 = (DefaultTableModel) this.Table_QLPB.getModel();
            /*tableModel.addColumn("idNV");
            tableModel.addColumn("tenNV");
            tableModel.addColumn("tenChucVu");
            tableModel.addColumn("heSoLuong");*/

            tableModel1.setRowCount(0);

            while (resultSet.next()) {
                String id = resultSet.getString("idPhongBan");
                String name = resultSet.getString("tenPhongBan");
                int soLuong = resultSet.getInt("soLuongNvPB");

                tableModel1.addRow(new Object[]{id, name, soLuong});
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void show_all_duan() {
        try {

            Statement statement = conn.createStatement();
            String sqlQuery = "SELECT DuAn.idDuAN, tenDuAn, COUNT(idNV) AS soLuongNvDuAn FROM DuAn LEFT OUTER JOIN NhanVien ON DuAn.idDuAn = NhanVien.idDuAn\n"
                    + "GROUP BY tenDuAn, DuAn.idDuAn";
            ResultSet resultSet = statement.executeQuery(sqlQuery);

            // Retrieve the table model from the JTable
            DefaultTableModel tableModel1 = (DefaultTableModel) this.Table_QLDuAn.getModel();
            /*tableModel.addColumn("idNV");
            tableModel.addColumn("tenNV");
            tableModel.addColumn("tenChucVu");
            tableModel.addColumn("heSoLuong");*/

            tableModel1.setRowCount(0);

            while (resultSet.next()) {
                String id = resultSet.getString("idDuAn");
                String name = resultSet.getString("tenDuAn");
                int soLuong = resultSet.getInt("soLuongNvDuAn");

                tableModel1.addRow(new Object[]{id, name, soLuong});
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane_QuanLyChung = new javax.swing.JTabbedPane();
        Panel_QLNhanVien = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        mainTable = new javax.swing.JTable();
        Txt_NV = new javax.swing.JTextField();
        Button_TimKiem_NV = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        Button_Xoa_NV = new javax.swing.JButton();
        button_Refresh_NV = new javax.swing.JButton();
        Button_Them_NV = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        Panel_QuanLyNhom = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        Table_QLNhom = new javax.swing.JTable();
        Button_Xoa__Nhom = new javax.swing.JButton();
        Txt_Nhom = new javax.swing.JTextField();
        Button_Refresh_Nhom = new javax.swing.JButton();
        Button_TimKiem_Nhom = new javax.swing.JButton();
        Button_Them_Nhom = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        Panel_QuanLyPhongBan = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        Table_QLPB = new javax.swing.JTable();
        Button_Xoa_PB = new javax.swing.JButton();
        Txt_PB = new javax.swing.JTextField();
        Button_Refresh_PB = new javax.swing.JButton();
        Button_TimKiem_PB = new javax.swing.JButton();
        Button_Them_PB = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        Panel_QuanLyDuAn = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        Table_QLDuAn = new javax.swing.JTable();
        Button_Xoa_DuAn = new javax.swing.JButton();
        Txt_DuAn = new javax.swing.JTextField();
        Button_Refresh_DuAn = new javax.swing.JButton();
        Button_TimKiem_DuAn = new javax.swing.JButton();
        Button_Them_DuAn = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        Panel_QuanLyChamCong = new javax.swing.JPanel();
        txt_TimKiem_CC = new javax.swing.JTextField();
        txt_dateCC = new javax.swing.JLabel();
        txt_Calam = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        Table_QLChamCong = new javax.swing.JTable();
        button_Refresh_ChamCong = new javax.swing.JButton();
        button_TimKiem_CC = new javax.swing.JButton();
        button_CheckCCorNot1 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Panel_QLNhanVien.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        mainTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Tên nhân viên", "CCCD", "Ngày sinh", "Giới tính", "SĐT", "Email", "Chức vụ", "Thuộc nhóm", "Phòng ban", "Dự án"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        mainTable.setOpaque(false);
        mainTable.setRowHeight(30);
        mainTable.setShowGrid(false);
        jScrollPane1.setViewportView(mainTable);
        if (mainTable.getColumnModel().getColumnCount() > 0) {
            mainTable.getColumnModel().getColumn(0).setResizable(false);
            mainTable.getColumnModel().getColumn(0).setPreferredWidth(20);
            mainTable.getColumnModel().getColumn(1).setResizable(false);
            mainTable.getColumnModel().getColumn(1).setPreferredWidth(100);
            mainTable.getColumnModel().getColumn(2).setResizable(false);
            mainTable.getColumnModel().getColumn(3).setResizable(false);
            mainTable.getColumnModel().getColumn(3).setPreferredWidth(40);
            mainTable.getColumnModel().getColumn(4).setResizable(false);
            mainTable.getColumnModel().getColumn(4).setPreferredWidth(10);
            mainTable.getColumnModel().getColumn(5).setResizable(false);
            mainTable.getColumnModel().getColumn(6).setResizable(false);
            mainTable.getColumnModel().getColumn(6).setPreferredWidth(120);
            mainTable.getColumnModel().getColumn(7).setResizable(false);
            mainTable.getColumnModel().getColumn(8).setResizable(false);
            mainTable.getColumnModel().getColumn(9).setResizable(false);
            mainTable.getColumnModel().getColumn(10).setResizable(false);
        }

        Panel_QLNhanVien.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, 1240, 560));

        Txt_NV.setText("Nhập ID NV");
        Txt_NV.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                Txt_NVFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                Txt_NVFocusLost(evt);
            }
        });
        Txt_NV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Txt_NVActionPerformed(evt);
            }
        });
        Panel_QLNhanVien.add(Txt_NV, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 10, 170, 30));

        Button_TimKiem_NV.setText("Tìm kiếm");
        Button_TimKiem_NV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_TimKiem_NVActionPerformed(evt);
            }
        });
        Panel_QLNhanVien.add(Button_TimKiem_NV, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 10, 100, 30));

        jButton3.setText("Sửa DA NV");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        Panel_QLNhanVien.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 10, -1, 30));

        jButton4.setText("Sửa Nhóm");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        Panel_QLNhanVien.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(467, 10, -1, 30));

        jButton2.setText("Sửa PB NV");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        Panel_QLNhanVien.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(276, 10, -1, 30));

        Button_Xoa_NV.setText("Xoá NV");
        Button_Xoa_NV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_Xoa_NVActionPerformed(evt);
            }
        });
        Panel_QLNhanVien.add(Button_Xoa_NV, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 10, 70, 30));

        button_Refresh_NV.setText("Refresh");
        button_Refresh_NV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_Refresh_NVActionPerformed(evt);
            }
        });
        Panel_QLNhanVien.add(button_Refresh_NV, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, 10, 100, 30));

        Button_Them_NV.setText("Thêm nhân viên");
        Button_Them_NV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_Them_NVActionPerformed(evt);
            }
        });
        Panel_QLNhanVien.add(Button_Them_NV, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 10, 120, 30));

        jButton1.setText("Sửa chức vụ");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        Panel_QLNhanVien.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 10, -1, 30));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pack1/pngQLChungPanel_QLNhanVien.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        Panel_QLNhanVien.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 630));

        jTabbedPane_QuanLyChung.addTab("Quản Lý Nhân Viên", Panel_QLNhanVien);

        Panel_QuanLyNhom.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Table_QLNhom.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Nhóm", "Tên Nhóm", "Số Lượng Nhân Viên"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        Table_QLNhom.setRowHeight(30);
        jScrollPane2.setViewportView(Table_QLNhom);
        if (Table_QLNhom.getColumnModel().getColumnCount() > 0) {
            Table_QLNhom.getColumnModel().getColumn(0).setResizable(false);
            Table_QLNhom.getColumnModel().getColumn(1).setResizable(false);
            Table_QLNhom.getColumnModel().getColumn(2).setResizable(false);
        }

        Panel_QuanLyNhom.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 80, 1040, 510));

        Button_Xoa__Nhom.setText("Xoá Nhóm");
        Button_Xoa__Nhom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_Xoa__NhomActionPerformed(evt);
            }
        });
        Panel_QuanLyNhom.add(Button_Xoa__Nhom, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 10, -1, 30));

        Txt_Nhom.setText("Nhập id nhóm");
        Txt_Nhom.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                Txt_NhomFocusGained(evt);
            }
        });
        Panel_QuanLyNhom.add(Txt_Nhom, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 10, 170, 30));

        Button_Refresh_Nhom.setText("Refresh");
        Button_Refresh_Nhom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_Refresh_NhomActionPerformed(evt);
            }
        });
        Panel_QuanLyNhom.add(Button_Refresh_Nhom, new org.netbeans.lib.awtextra.AbsoluteConstraints(1200, 10, -1, 30));

        Button_TimKiem_Nhom.setText("Tìm Kiếm");
        Button_TimKiem_Nhom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_TimKiem_NhomActionPerformed(evt);
            }
        });
        Panel_QuanLyNhom.add(Button_TimKiem_Nhom, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 10, 100, 30));

        Button_Them_Nhom.setText("Thêm Nhóm");
        Button_Them_Nhom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_Them_NhomActionPerformed(evt);
            }
        });
        Panel_QuanLyNhom.add(Button_Them_Nhom, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 10, 100, 30));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pack1/pngQLChungPanel_QLNhom.png"))); // NOI18N
        jLabel3.setText("jLabel3");
        Panel_QuanLyNhom.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, -1));

        jTabbedPane_QuanLyChung.addTab("Quản Lý Nhóm", Panel_QuanLyNhom);

        Panel_QuanLyPhongBan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Table_QLPB.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Phòng Ban", "Tên Phòng Ban", "Số Lượng Nhân Viên"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        Table_QLPB.setRowHeight(30);
        jScrollPane3.setViewportView(Table_QLPB);
        if (Table_QLPB.getColumnModel().getColumnCount() > 0) {
            Table_QLPB.getColumnModel().getColumn(0).setResizable(false);
            Table_QLPB.getColumnModel().getColumn(1).setResizable(false);
            Table_QLPB.getColumnModel().getColumn(2).setResizable(false);
        }

        Panel_QuanLyPhongBan.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 80, 1030, 520));

        Button_Xoa_PB.setText("Xoá PB");
        Button_Xoa_PB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_Xoa_PBActionPerformed(evt);
            }
        });
        Panel_QuanLyPhongBan.add(Button_Xoa_PB, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 10, 90, 30));

        Txt_PB.setText("Nhập id PB");
        Txt_PB.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                Txt_PBFocusGained(evt);
            }
        });
        Panel_QuanLyPhongBan.add(Txt_PB, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 10, 170, 30));

        Button_Refresh_PB.setText("Refresh");
        Button_Refresh_PB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_Refresh_PBActionPerformed(evt);
            }
        });
        Panel_QuanLyPhongBan.add(Button_Refresh_PB, new org.netbeans.lib.awtextra.AbsoluteConstraints(1200, 10, -1, 30));

        Button_TimKiem_PB.setText("Tìm Kiếm");
        Button_TimKiem_PB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_TimKiem_PBActionPerformed(evt);
            }
        });
        Panel_QuanLyPhongBan.add(Button_TimKiem_PB, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 10, 100, 30));

        Button_Them_PB.setText("Thêm PB");
        Button_Them_PB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_Them_PBActionPerformed(evt);
            }
        });
        Panel_QuanLyPhongBan.add(Button_Them_PB, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 10, 100, 30));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pack1/pngQLChungPanel_QLPhongBan.png"))); // NOI18N
        jLabel4.setText("jLabel4");
        Panel_QuanLyPhongBan.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 630));

        jTabbedPane_QuanLyChung.addTab("Quản Lý Phòng Ban", Panel_QuanLyPhongBan);

        Panel_QuanLyDuAn.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Table_QLDuAn.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Phòng Ban", "Tên Phòng Ban", "Số Lượng"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        Table_QLDuAn.setRowHeight(30);
        jScrollPane4.setViewportView(Table_QLDuAn);
        if (Table_QLDuAn.getColumnModel().getColumnCount() > 0) {
            Table_QLDuAn.getColumnModel().getColumn(0).setResizable(false);
            Table_QLDuAn.getColumnModel().getColumn(1).setResizable(false);
            Table_QLDuAn.getColumnModel().getColumn(2).setResizable(false);
        }

        Panel_QuanLyDuAn.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 80, 1030, 520));

        Button_Xoa_DuAn.setText("Xoá Dự Án");
        Button_Xoa_DuAn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_Xoa_DuAnActionPerformed(evt);
            }
        });
        Panel_QuanLyDuAn.add(Button_Xoa_DuAn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 10, 90, 30));

        Txt_DuAn.setText("Nhập id dự án");
        Txt_DuAn.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                Txt_DuAnFocusGained(evt);
            }
        });
        Panel_QuanLyDuAn.add(Txt_DuAn, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 10, 170, 30));

        Button_Refresh_DuAn.setText("Refresh");
        Button_Refresh_DuAn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_Refresh_DuAnActionPerformed(evt);
            }
        });
        Panel_QuanLyDuAn.add(Button_Refresh_DuAn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1200, 10, -1, 30));

        Button_TimKiem_DuAn.setText("Tìm Kiếm");
        Button_TimKiem_DuAn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_TimKiem_DuAnActionPerformed(evt);
            }
        });
        Panel_QuanLyDuAn.add(Button_TimKiem_DuAn, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 10, 100, 30));

        Button_Them_DuAn.setText("Thêm Dự Án");
        Button_Them_DuAn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_Them_DuAnActionPerformed(evt);
            }
        });
        Panel_QuanLyDuAn.add(Button_Them_DuAn, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 10, 100, 30));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pack1/pngQLChungPanel_QLDuAn.png"))); // NOI18N
        jLabel5.setText("jLabel5");
        Panel_QuanLyDuAn.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 630));

        jTabbedPane_QuanLyChung.addTab("Quản Lý Dự Án", Panel_QuanLyDuAn);

        Panel_QuanLyChamCong.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txt_TimKiem_CC.setText("Nhập id Nhân viên");
        txt_TimKiem_CC.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_TimKiem_CCFocusGained(evt);
            }
        });
        Panel_QuanLyChamCong.add(txt_TimKiem_CC, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 40, 180, 40));

        txt_dateCC.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        txt_dateCC.setForeground(new java.awt.Color(255, 255, 255));
        txt_dateCC.setText("dd-MM-yyyy");
        Panel_QuanLyChamCong.add(txt_dateCC, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 0, 260, 40));

        txt_Calam.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        txt_Calam.setForeground(new java.awt.Color(255, 255, 255));
        txt_Calam.setText("Ca Sáng");
        Panel_QuanLyChamCong.add(txt_Calam, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 0, 150, 40));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Ca hiện tại:");
        Panel_QuanLyChamCong.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 0, 150, 40));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Hôm nay là:");
        Panel_QuanLyChamCong.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 0, 150, 40));

        Table_QLChamCong.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Nhân Viên", "Tên Nhân Viên", "Phòng Ban", "Dự Án", "Nhóm"
            }
        ));
        Table_QLChamCong.setRowHeight(30);
        jScrollPane5.setViewportView(Table_QLChamCong);

        Panel_QuanLyChamCong.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 107, 1240, 510));

        button_Refresh_ChamCong.setText("Refresh");
        button_Refresh_ChamCong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_Refresh_ChamCongActionPerformed(evt);
            }
        });
        Panel_QuanLyChamCong.add(button_Refresh_ChamCong, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 40, 100, 40));

        button_TimKiem_CC.setText("Tìm Kiếm");
        button_TimKiem_CC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_TimKiem_CCActionPerformed(evt);
            }
        });
        Panel_QuanLyChamCong.add(button_TimKiem_CC, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 40, 100, 40));

        button_CheckCCorNot1.setText("Chấm Công");
        button_CheckCCorNot1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_CheckCCorNot1ActionPerformed(evt);
            }
        });
        Panel_QuanLyChamCong.add(button_CheckCCorNot1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1170, 40, 100, 40));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pack1/pngQLChungPanel_QLChamCong.png"))); // NOI18N
        jLabel9.setText("jLabel9");
        Panel_QuanLyChamCong.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 1280, 650));

        jTabbedPane_QuanLyChung.addTab("Quản Lý Dữ Liệu Chấm Công", Panel_QuanLyChamCong);

        getContentPane().add(jTabbedPane_QuanLyChung, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 1280, 670));
        jTabbedPane_QuanLyChung.getAccessibleContext().setAccessibleName("tab 1");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pack1/pngQLchungFullTabbed.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -4, 1280, 720));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Button_Refresh_DuAnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_Refresh_DuAnActionPerformed
        // TODO add your handling code here:
        show_all_duan();
    }//GEN-LAST:event_Button_Refresh_DuAnActionPerformed

    private void Button_Xoa_DuAnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_Xoa_DuAnActionPerformed
        // TODO add your handling code here:
        try {

            Statement statement = conn.createStatement();
            this.duanOfQuanLyChung.setIdDuAn(Txt_DuAn.getText());
            //xoa 1 chuc vu
            int countrow = statement.executeUpdate("delete from DuAn where idDuAn = N'" + this.duanOfQuanLyChung.getIdDuAn() + "'");
            // Close the connection and resources
            statement.close();

            //kiem tra thanh cong hay khong
            if (countrow == 0) {
                JOptionPane.showMessageDialog(null, "Xóa Dự Án thất bại. Vui lòng kiểm tra lại thông tin");
            } else {
                JOptionPane.showMessageDialog(null, "Xóa Dự Án thành công!");
                Txt_DuAn.setText("");
                this.Table_QLDuAn.repaint();
            }

        } catch (SQLServerException eb) {
            JOptionPane.showMessageDialog(this, "Dự án vẫn còn người, ko xoá dc");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_Button_Xoa_DuAnActionPerformed

    private void Button_Refresh_PBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_Refresh_PBActionPerformed
        // TODO add your handling code here:
        show_all_pb();
    }//GEN-LAST:event_Button_Refresh_PBActionPerformed

    private void Button_Xoa_PBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_Xoa_PBActionPerformed
        // TODO add your handling code here:
        try {

            Statement statement = conn.createStatement();
            this.pbOfQuanLyChung.setIdPhongBan(Txt_PB.getText());
            //xoa 1 chuc vu
            int countrow = statement.executeUpdate("delete from PhongBan where idPhongBan = N'" + this.pbOfQuanLyChung.getIdPhongBan() + "'");
            // Close the connection and resources
            statement.close();

            //kiem tra thanh cong hay khong
            if (countrow == 0) {
                JOptionPane.showMessageDialog(null, "Xóa Phòng Ban thất bại. Vui lòng kiểm tra lại thông tin!");
            } else {
                JOptionPane.showMessageDialog(null, "Xóa Phòng Ban thành công!");
                Txt_PB.setText("");
                this.Table_QLPB.repaint();
            }

        } catch (SQLServerException eb) {
            JOptionPane.showMessageDialog(this, "Phòng ban vẫn còn người, ko xoá dc");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_Button_Xoa_PBActionPerformed

    private void Button_Refresh_NhomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_Refresh_NhomActionPerformed
        // TODO add your handling code here:
        show_all_nhom();
    }//GEN-LAST:event_Button_Refresh_NhomActionPerformed

    private void Button_Xoa__NhomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_Xoa__NhomActionPerformed
        // TODO add your handling code here:
        try {

            Statement statement = conn.createStatement();
            this.nhomOfQuanLyChung.setIdNhom(Txt_Nhom.getText());
            //xoa 1 chuc vu
            int countrow = statement.executeUpdate("delete from Nhom where idNhom = N'" + this.nhomOfQuanLyChung.getIdNhom() + "'");
            // Close the connection and resources
            statement.close();

            //kiem tra thanh cong hay khong
            if (countrow == 0) {
                JOptionPane.showMessageDialog(null, "Xóa Nhóm thất bại. Vui lòng kiểm tra lại thông tin!");
            } else {
                JOptionPane.showMessageDialog(null, "Xóa Nhóm thành công!");
                Txt_Nhom.setText("");
                this.Table_QLNhom.repaint();
            }

        } catch (SQLServerException eb) {
            JOptionPane.showMessageDialog(this, "Nhóm vẫn còn người, ko xoá dc");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_Button_Xoa__NhomActionPerformed

    private void Button_Them_NVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_Them_NVActionPerformed
        // TODO add your handling code here:
        new ThemNhanVienForm().setVisible(true);
    }//GEN-LAST:event_Button_Them_NVActionPerformed

    private void button_Refresh_NVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_Refresh_NVActionPerformed
        // TODO add your handling code here:
        show_all_nv();
    }//GEN-LAST:event_button_Refresh_NVActionPerformed

    private void Button_Xoa_NVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_Xoa_NVActionPerformed
        // TODO add your handling code here:
        try {

            Statement statement = conn.createStatement();

            this.nvOfQuanLyChung.setIdNV(Txt_NV.getText());
            //xoa 1 chuc vu
            int countrow2 = statement.executeUpdate("delete from ChamCong where idNV = N'" + this.nvOfQuanLyChung.getIdNV() + "'");
            int countrow = statement.executeUpdate("delete from NhanVien where idNV = N'" + this.nvOfQuanLyChung.getIdNV() + "'");
            // Close the connection and resources
            statement.close();

            //kiem tra thanh cong hay khong
            if (countrow == 0) {
                JOptionPane.showMessageDialog(null, "Xóa nhân viên thất bại! Vui lòng kiểm tra lại thông tin!");
            } else {
                JOptionPane.showMessageDialog(null, "Xóa nhân viên " + this.nvOfQuanLyChung.getTenNV() + " thành công!");
                Txt_NV.setText("");
                this.mainTable.repaint();
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_Button_Xoa_NVActionPerformed

    private void Button_TimKiem_NVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_TimKiem_NVActionPerformed
        try {
            Statement statement = conn.createStatement();
            this.nvOfQuanLyChung.setIdNV(Txt_NV.getText());

            String sqlQuery = "SELECT * FROM NhanVien LEFT OUTER JOIN ChucVu ON NhanVien.tenChucVu = ChucVu.tenChucVu LEFT OUTER JOIN Nhom ON NhanVien.idNhom = Nhom.idNhom LEFT OUTER JOIN DuAn ON NhanVien.idDuAn = DuAn.idDuAn LEFT OUTER JOIN PhongBan ON NhanVien.idPhongBan = PhongBan.idPhongBan WHERE idNV = N'" + this.nvOfQuanLyChung.getIdNV() + "'";
            ResultSet resultSet = statement.executeQuery(sqlQuery);

            // Retrieve the table model from the JTable
            DefaultTableModel tableModel1 = (DefaultTableModel) this.mainTable.getModel();
            /*tableModel.addColumn("idNV");
            tableModel.addColumn("tenNV");
            tableModel.addColumn("tenChucVu");
            tableModel.addColumn("heSoLuong");*/

            tableModel1.setRowCount(0);

            while (resultSet.next()) {
                String id = resultSet.getString("idNV");
                String name = resultSet.getString("tenNV");
                String cccd = resultSet.getString("CCCD");
                String ngaySinh = resultSet.getString("ngaySinhNV");
                String email = resultSet.getString("emailNV");
                String sdt = resultSet.getString("sdtNV");
                boolean gioiTinh = resultSet.getBoolean("gioiTinhNV");
                String nhom = resultSet.getString("tenNhom");
                String phongBan = resultSet.getString("tenPhongBan");
                String duAn = resultSet.getString("tenDuAn");
                String chucVu = resultSet.getString("tenChucVu");

                String gioiTinhString = "";

                if (gioiTinh) {
                    gioiTinhString = "Nam";
                } else {
                    gioiTinhString = "Nữ";
                }

                tableModel1.addRow(new Object[]{id, name, cccd, ngaySinh, gioiTinhString, sdt, email, chucVu, nhom, phongBan, duAn});
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_Button_TimKiem_NVActionPerformed

    private void Button_Them_NhomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_Them_NhomActionPerformed
        // TODO add your handling code here:
        new ThemNhom("Nhom").setVisible(true);
    }//GEN-LAST:event_Button_Them_NhomActionPerformed

    private void Button_Them_PBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_Them_PBActionPerformed
        // TODO add your handling code here:
        new ThemNhom("PhongBan").setVisible(true);
    }//GEN-LAST:event_Button_Them_PBActionPerformed

    private void Button_TimKiem_PBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_TimKiem_PBActionPerformed
        try {

            Statement statement = conn.createStatement();
            this.pbOfQuanLyChung.setIdPhongBan(Txt_PB.getText());
            String sqlQuery = "SELECT PhongBan.idPhongBan, tenPhongBan, COUNT(idNV) AS soLuongNvPB FROM PhongBan LEFT OUTER JOIN NhanVien ON PhongBan.idPhongBan = NhanVien.idPhongBan WHERE PhongBan.idPhongBan = N'" + this.pbOfQuanLyChung.getIdPhongBan() + "' GROUP BY tenPhongBan, PhongBan.idPhongBan";
            ResultSet resultSet = statement.executeQuery(sqlQuery);

            // Retrieve the table model from the JTable
            DefaultTableModel tableModel1 = (DefaultTableModel) this.Table_QLPB.getModel();
            /*tableModel.addColumn("idNV");
            tableModel.addColumn("tenNV");
            tableModel.addColumn("tenChucVu");
            tableModel.addColumn("heSoLuong");*/

            tableModel1.setRowCount(0);

            while (resultSet.next()) {
                String id = resultSet.getString("idPhongBan");
                String name = resultSet.getString("tenPhongBan");
                int soLuong = resultSet.getInt("soLuongNvPB");

                tableModel1.addRow(new Object[]{id, name, soLuong});
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_Button_TimKiem_PBActionPerformed

    private void Button_Them_DuAnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_Them_DuAnActionPerformed
        // TODO add your handling code here:
        new ThemNhom("DuAn").setVisible(true);
    }//GEN-LAST:event_Button_Them_DuAnActionPerformed

    private void Button_TimKiem_DuAnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_TimKiem_DuAnActionPerformed
        try {
            Statement statement = conn.createStatement();
            this.duanOfQuanLyChung.setIdDuAn(Txt_DuAn.getText());
            String sqlQuery = "SELECT DuAn.idDuAN, tenDuAn, COUNT(idNV) AS soLuongNvDuAn FROM DuAn LEFT OUTER JOIN NhanVien ON DuAn.idDuAn = NhanVien.idDuAn WHERE DuAn.idDuAN = N'" + this.duanOfQuanLyChung.getIdDuAn() + "' GROUP BY tenDuAn, DuAn.idDuAn";
            ResultSet resultSet = statement.executeQuery(sqlQuery);

            // Retrieve the table model from the JTable
            DefaultTableModel tableModel1 = (DefaultTableModel) this.Table_QLDuAn.getModel();
            /*tableModel.addColumn("idNV");
            tableModel.addColumn("tenNV");
            tableModel.addColumn("tenChucVu");
            tableModel.addColumn("heSoLuong");*/

            tableModel1.setRowCount(0);

            while (resultSet.next()) {
                String id = resultSet.getString("idDuAn");
                String name = resultSet.getString("tenDuAn");
                int soLuong = resultSet.getInt("soLuongNvDuAn");

                tableModel1.addRow(new Object[]{id, name, soLuong});
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_Button_TimKiem_DuAnActionPerformed

    private void Button_TimKiem_NhomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_TimKiem_NhomActionPerformed
        try {

            Statement statement = conn.createStatement();
            this.nhomOfQuanLyChung.setIdNhom(Txt_Nhom.getText());
            String sqlQuery = "SELECT Nhom.idNhom, tenNhom , COUNT(idNV) AS soLuongNvNhom FROM Nhom LEFT OUTER JOIN NhanVien ON Nhom.idNhom = NhanVien.idNhom where Nhom.idNhom = '" + this.nhomOfQuanLyChung.getIdNhom() + "' GROUP BY tenNhom, Nhom.idNhom ";
            //String sqlQuery = "SELECT Nhom.idNhom, tenNhom , COUNT(idNV) AS soLuongNvNhom FROM Nhom LEFT OUTER JOIN NhanVien ON Nhom.idNhom = NhanVien.idNhom GROUP BY tenNhom, Nhom.idNhom ";
            ResultSet resultSet = statement.executeQuery(sqlQuery);

            // Retrieve the table model from the JTable
            DefaultTableModel tableModel1 = (DefaultTableModel) this.Table_QLNhom.getModel();
            /*tableModel.addColumn("idNV");
            tableModel.addColumn("tenNV");
            tableModel.addColumn("tenChucVu");
            tableModel.addColumn("heSoLuong");*/

            tableModel1.setRowCount(0);

            while (resultSet.next()) {
                String id = resultSet.getString("idNhom");
                String name = resultSet.getString("tenNhom");
                int soLuong = resultSet.getInt("soLuongNvNhom");

                tableModel1.addRow(new Object[]{id, name, soLuong});
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_Button_TimKiem_NhomActionPerformed

    private void Txt_NVFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_Txt_NVFocusGained
        // TODO add your handling code here:
        this.Txt_NV.setText("");
    }//GEN-LAST:event_Txt_NVFocusGained

    private void Txt_NVFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_Txt_NVFocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_Txt_NVFocusLost

    private void Txt_NVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Txt_NVActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Txt_NVActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        if (this.mainTable.getSelectedRow() >= 0) {
            String idNVselected = (String) mainTable.getValueAt(mainTable.getSelectedRow(), 0);
            new SuaChucVu(idNVselected).setVisible(true);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void Txt_DuAnFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_Txt_DuAnFocusGained
        // TODO add your handling code here:
        Txt_DuAn.setText("");
    }//GEN-LAST:event_Txt_DuAnFocusGained

    private void Txt_PBFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_Txt_PBFocusGained
        // TODO add your handling code here:
        Txt_PB.setText("");
    }//GEN-LAST:event_Txt_PBFocusGained

    private void Txt_NhomFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_Txt_NhomFocusGained
        // TODO add your handling code here:
        Txt_Nhom.setText("");
    }//GEN-LAST:event_Txt_NhomFocusGained

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        if (this.mainTable.getSelectedRow() >= 0) {
            String idNVselected = (String) mainTable.getValueAt(mainTable.getSelectedRow(), 0);
            new SuaPBDAN("PhongBan", idNVselected).setVisible(true);
        }

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        if (this.mainTable.getSelectedRow() >= 0) {
            String idNVselected = (String) mainTable.getValueAt(mainTable.getSelectedRow(), 0);
            new SuaPBDAN("Nhom", idNVselected).setVisible(true);
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        if (this.mainTable.getSelectedRow() >= 0) {
            String idNVselected = (String) mainTable.getValueAt(mainTable.getSelectedRow(), 0);
            new SuaPBDAN("DuAn", idNVselected).setVisible(true);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void txt_TimKiem_CCFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_TimKiem_CCFocusGained
        // TODO add your handling code here:
        // TODO add your handling code here:
        this.txt_TimKiem_CC.setText("");
    }//GEN-LAST:event_txt_TimKiem_CCFocusGained

    private void button_Refresh_ChamCongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_Refresh_ChamCongActionPerformed
        // TODO add your handling code here:
        show_cham_cong();
        show_ngay_cc();
    }//GEN-LAST:event_button_Refresh_ChamCongActionPerformed

    private void button_TimKiem_CCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_TimKiem_CCActionPerformed
        // TODO add your handling code here:
        try {
            Statement statement = conn.createStatement();
            this.nvChamCongOfQLChung.setIdNV(txt_TimKiem_CC.getText());

            String sqlQuery = "SELECT idNV, tenNV, tenNhom, tenPhongBan, tenDuAn FROM NhanVien LEFT OUTER JOIN ChucVu ON NhanVien.tenChucVu = ChucVu.tenChucVu LEFT OUTER JOIN Nhom ON NhanVien.idNhom = Nhom.idNhom LEFT OUTER JOIN DuAn ON NhanVien.idDuAn = DuAn.idDuAn LEFT OUTER JOIN PhongBan ON NhanVien.idPhongBan = PhongBan.idPhongBan WHERE idNV = N'" + this.nvChamCongOfQLChung.getIdNV() + "'";
            ResultSet resultSet = statement.executeQuery(sqlQuery);

            // Retrieve the table model from the JTable
            DefaultTableModel tableModel1 = (DefaultTableModel) this.Table_QLChamCong.getModel();
            /*tableModel.addColumn("idNV");
            tableModel.addColumn("tenNV");
            tableModel.addColumn("tenChucVu");
            tableModel.addColumn("heSoLuong");*/

            tableModel1.setRowCount(0);

            while (resultSet.next()) {
                String id = resultSet.getString("idNV");
                String name = resultSet.getString("tenNV");
                String nhom = resultSet.getString("tenNhom");
                String phongBan = resultSet.getString("tenPhongBan");
                String duAn = resultSet.getString("tenDuAn");
                tableModel1.addRow(new Object[]{id, name, phongBan, duAn, nhom});
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_button_TimKiem_CCActionPerformed

    private void button_CheckCCorNot1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_CheckCCorNot1ActionPerformed
        // TODO add your handling code here:
        try {
            LocalDateTime ld = LocalDateTime.now();
            String day = String.valueOf(ld.getDayOfMonth());
            String month = String.valueOf(ld.getMonthValue());
            String year = String.valueOf(ld.getYear());

            DateTimeFormatter formatterFulltime = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String timeFull = ld.format(formatterFulltime);


            if (this.Table_QLChamCong.getSelectedRow() >= 0) {
                String idNVselected = (String) Table_QLChamCong.getValueAt(Table_QLChamCong.getSelectedRow(), 0);
                Statement statement = conn.createStatement();
                // lay ra ngay, thang, nam cham cong de check xem hom nay nhan vien nay da cham cong chua
                String sqlCheckCCorNot = "select datepart(day, timeChamCong) as ngayCC, "
                        + "datepart(month, timeChamCong) as thangCC, "
                        + "datepart(year, timeChamCong) as namCC "
                        + "from ChamCong where idNV = '" + idNVselected + "' "
                        + "AND datepart(day, timeChamCong) = " + day
                        + " AND datepart(month, timeChamCong) = " + month
                        + " AND datepart(year, timeChamCong) = " + year;
                ResultSet rs = statement.executeQuery(sqlCheckCCorNot);
                if (rs.next()) { //da co du lieu cham cong tai ngay, thang, nam hien tai
                    JOptionPane.showMessageDialog(null, "Nhân viên này hôm nay đã được chấm công", "LỖI RỒI!!", HEIGHT);
                } else {
                    
                    PreparedStatement statement1 = conn.prepareStatement("Insert into ChamCong (tenCaLam, idNV, timeChamCong) values(?, ?, ?);");
                    statement1.setString(1, this.txt_Calam.getText());
                    statement1.setString(2, idNVselected);
                    statement1.setString(3, timeFull);
                    int countr = statement1.executeUpdate();
                    if(countr != 0) {
                        JOptionPane.showMessageDialog(null, "Chấm công thành công cho nhân viên " + idNVselected);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_button_CheckCCorNot1ActionPerformed

    private void show_ngay_cc() {
        LocalDateTime ld = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("HH");
        this.txt_dateCC.setText(ld.format(formatter));

        int checkTime = Integer.parseInt(ld.format(formatter2));
        int tgBatDauCaSang = 0, tgKetThucCaSang = 0, tgBatDauCaChieu = 0, tgKetThucCaChieu = 0;

        try {
            Statement stm = conn.createStatement();
            Statement stm2 = conn.createStatement();
            String sqlSangStart = "select datepart(hour, timeStart) as tgBatDau, datepart(hour, timeEnd) as tgKetThuc  from CaLam where tenCaLam = N'Ca Sáng'";
            String sqlChieuStart = "select datepart(hour, timeStart) as tgBatDauC, datepart(hour, timeEnd) as tgKetThucC  from CaLam where tenCaLam = N'Ca Tối'";
            ResultSet rs = stm.executeQuery(sqlSangStart);
            ResultSet rs2 = stm2.executeQuery(sqlChieuStart);

            if (rs.next()) {
                tgBatDauCaSang = rs.getInt("tgBatDau");
                tgKetThucCaSang = rs.getInt("tgKetThuc");
            }

            //System.out.println(tgBatDauCaSang);
            //System.out.println(tgKetThucCaSang);
            if (rs2.next()) {
                tgBatDauCaChieu = rs2.getInt("tgBatDauC");
                tgKetThucCaChieu = rs2.getInt("tgKetThucC");
            }

            //System.out.println(tgBatDauCaChieu);
            //System.out.println(tgKetThucCaChieu);
            if (checkTime >= tgBatDauCaSang && checkTime <= tgKetThucCaSang) {
                this.txt_Calam.setText("Ca Sáng");
            } else if (checkTime >= tgBatDauCaChieu && checkTime <= tgKetThucCaChieu) {
                this.txt_Calam.setText("Ca Tối");
            } else {
                this.txt_Calam.setText("Nghỉ");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    public void show_cham_cong() {

        // ngay thang nam
        try {

            Statement statement = conn.createStatement();
            String sqlQuery = "select NhanVien.idNV, NhanVien.tenNV, PhongBan.tenPhongBan, DuAn.tenDuAn, Nhom.tenNhom from NhanVien left join PhongBan on NhanVien.idPhongBan = PhongBan.idPhongBan left join DuAn on NhanVien.idDuAn = DuAn.idDuAn left join Nhom on NhanVien.idNhom = Nhom.idNhom";
            ResultSet resultSet = statement.executeQuery(sqlQuery);

            // Retrieve the table model from the JTable
            DefaultTableModel tableModel1 = (DefaultTableModel) this.Table_QLChamCong.getModel();
            tableModel1.setRowCount(0);

            while (resultSet.next()) {
                String id = resultSet.getString("idNV");
                String name = resultSet.getString("tenNV");
                String phongban = resultSet.getString("tenPhongBan");
                String duan = resultSet.getString("tenDuAn");
                String nhom = resultSet.getString("tenNhom");

                tableModel1.addRow(new Object[]{id, name, phongban, duan, nhom});
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QuanLyChung.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QuanLyChung.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QuanLyChung.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QuanLyChung.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new QuanLyChung().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Button_Refresh_DuAn;
    private javax.swing.JButton Button_Refresh_Nhom;
    private javax.swing.JButton Button_Refresh_PB;
    private javax.swing.JButton Button_Them_DuAn;
    private javax.swing.JButton Button_Them_NV;
    private javax.swing.JButton Button_Them_Nhom;
    private javax.swing.JButton Button_Them_PB;
    private javax.swing.JButton Button_TimKiem_DuAn;
    private javax.swing.JButton Button_TimKiem_NV;
    private javax.swing.JButton Button_TimKiem_Nhom;
    private javax.swing.JButton Button_TimKiem_PB;
    private javax.swing.JButton Button_Xoa_DuAn;
    private javax.swing.JButton Button_Xoa_NV;
    private javax.swing.JButton Button_Xoa_PB;
    private javax.swing.JButton Button_Xoa__Nhom;
    private javax.swing.JPanel Panel_QLNhanVien;
    private javax.swing.JPanel Panel_QuanLyChamCong;
    private javax.swing.JPanel Panel_QuanLyDuAn;
    private javax.swing.JPanel Panel_QuanLyNhom;
    private javax.swing.JPanel Panel_QuanLyPhongBan;
    private javax.swing.JTable Table_QLChamCong;
    private javax.swing.JTable Table_QLDuAn;
    private javax.swing.JTable Table_QLNhom;
    private javax.swing.JTable Table_QLPB;
    private javax.swing.JTextField Txt_DuAn;
    private javax.swing.JTextField Txt_NV;
    private javax.swing.JTextField Txt_Nhom;
    private javax.swing.JTextField Txt_PB;
    private javax.swing.JButton button_CheckCCorNot1;
    private javax.swing.JButton button_Refresh_ChamCong;
    private javax.swing.JButton button_Refresh_NV;
    private javax.swing.JButton button_TimKiem_CC;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTabbedPane jTabbedPane_QuanLyChung;
    private javax.swing.JTable mainTable;
    private javax.swing.JLabel txt_Calam;
    private javax.swing.JTextField txt_TimKiem_CC;
    private javax.swing.JLabel txt_dateCC;
    // End of variables declaration//GEN-END:variables
}
