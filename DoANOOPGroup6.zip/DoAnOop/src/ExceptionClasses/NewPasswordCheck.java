/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ExceptionClasses;

/**
 *
 * @author HOANG DILO
 */
public class NewPasswordCheck extends Exception{

    public NewPasswordCheck() {
    }
    
}
