/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ExceptionClasses;

/**
 *
 * @author HOANG DILO
 */
public class CheckDoiMK extends Exception {

    private String tkCheck;
    private String mkCheck;

    public CheckDoiMK(String tk, String mk) {
        this.tkCheck = tk;
        this.mkCheck = mk;
    }

    public CheckDoiMK() {
    }

    public String getTkCheck() {
        return tkCheck;
    }

    public String getMkCheck() {
        return mkCheck;
    }

}
