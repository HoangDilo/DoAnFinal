/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

import java.time.LocalTime;

/**
 *
 * @author HOANG DILO
 */
public class CaLam {
    private String tenCL;
    private int luongCL;
    private LocalTime timeStart;
    private LocalTime timeEnd;

    public CaLam() {
    }

    public String getTenCL() {
        return tenCL;
    }

    public void setTenCL(String tenCL) {
        this.tenCL = tenCL;
    }

    public int getLuongCL() {
        return luongCL;
    }

    public void setLuongCL(int luongCL) {
        this.luongCL = luongCL;
    }

    public LocalTime getTimeStart() {
        return timeStart;
    }

    public void setTimeStart(LocalTime timeStart) {
        this.timeStart = timeStart;
    }

    public LocalTime getTimeEnd() {
        return timeEnd;
    }

    public void setTimeEnd(LocalTime timeEnd) {
        this.timeEnd = timeEnd;
    }
    
}
