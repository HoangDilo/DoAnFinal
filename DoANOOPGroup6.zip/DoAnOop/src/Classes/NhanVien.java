/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;
import java.time.*;

/**
 *
 * @author HOANG DILO
 */
public class NhanVien {
    private String idNV;
    private String tenNV;
    private String CCCD;
    private LocalDate ngaySinhNV;
    private String emailNV;
    private String sdtNV;
    private boolean gioiTinhNV; //1 - nam; 0 - nu
    private String chucvuNV;
    private String idPhongBan;
    private String idDuAn;
    private String idNhom;
    private String account;
    private String password;

    public NhanVien() {
    }

    public String getIdNV() {
        return idNV;
    }

    public void setIdNV(String idNV) {
        this.idNV = idNV;
    }

    public String getTenNV() {
        return tenNV;
    }

    public void setTenNV(String tenNV) {
        this.tenNV = tenNV;
    }

    public String getCCCD() {
        return CCCD;
    }

    public void setCCCD(String CCCD) {
        this.CCCD = CCCD;
    }

    public LocalDate getNgaySinhNV() {
        return ngaySinhNV;
    }

    public void setNgaySinhNV(LocalDate ngaySinhNV) {
        this.ngaySinhNV = ngaySinhNV;
    }

    public String getEmailNV() {
        return emailNV;
    }

    public void setEmailNV(String emailNV) {
        this.emailNV = emailNV;
    }

    public String getSdtNV() {
        return sdtNV;
    }

    public void setSdtNV(String sdtNV) {
        this.sdtNV = sdtNV;
    }

    public boolean isGioiTinhNV() {
        return gioiTinhNV;
    }

    public void setGioiTinhNV(boolean gioiTinhNV) {
        this.gioiTinhNV = gioiTinhNV;
    }

    public String getChucvuNV() {
        return chucvuNV;
    }

    public void setChucvuNV(String chucvuNV) {
        this.chucvuNV = chucvuNV;
    }

    public String getIdPhongBan() {
        return idPhongBan;
    }

    public void setIdPhongBan(String idPhongBan) {
        this.idPhongBan = idPhongBan;
    }

    public String getIdDuAn() {
        return idDuAn;
    }

    public void setIdDuAn(String idDuAn) {
        this.idDuAn = idDuAn;
    }

    public String getIdNhom() {
        return idNhom;
    }

    public void setIdNhom(String idNhom) {
        this.idNhom = idNhom;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    
    
}