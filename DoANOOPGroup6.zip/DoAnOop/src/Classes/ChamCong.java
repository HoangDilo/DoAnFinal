/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;
import java.time.*;
/**
 *
 * @author HOANG DILO
 */
public class ChamCong {
    private String idChamCong;
    private String idNV;
    private String tenCL;
    private LocalDateTime timeChamCong;
    public ChamCong() {
    }

    public String getIdNV() {
        return idNV;
    }

    public String getTenCL() {
        return tenCL;
    }

    public void setIdNV(String idNV) {
        this.idNV = idNV;
    }

    public void setTenCL(String tenCL) {
        this.tenCL = tenCL;
    }

    public String getIdChamCong() {
        return idChamCong;
    }

    public void setIdChamCong(String idChamCong) {
        this.idChamCong = idChamCong;
    }

    public LocalDateTime getTimeChamCong() {
        return timeChamCong;
    }

    public void setTimeChamCong(LocalDateTime timeChamCong) {
        this.timeChamCong = timeChamCong;
    }
    
    
}
