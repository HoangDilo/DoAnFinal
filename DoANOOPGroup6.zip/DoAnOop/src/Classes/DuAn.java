/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author HOANG DILO
 */
public class DuAn {
    private String idDuAn;
    private String tenDuAn;


    public DuAn() {
    }

    public String getIdDuAn() {
        return idDuAn;
    }

    public void setIdDuAn(String idDuAn) {
        this.idDuAn = idDuAn;
    }

    public String getTenDuAn() {
        return tenDuAn;
    }

    public void setTenDuAn(String tenDuAn) {
        this.tenDuAn = tenDuAn;
    }

    
}
