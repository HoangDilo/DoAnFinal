/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

/**
 *
 * @author HOANG DILO
 */
public class PhongBan {
    private String idPhongBan;
    private String tenPhongBan;


    public PhongBan() {
    }

    public String getIdPhongBan() {
        return idPhongBan;
    }

    public void setIdPhongBan(String idPhongBan) {
        this.idPhongBan = idPhongBan;
    }

    public String getTenPhongBan() {
        return tenPhongBan;
    }

    public void setTenPhongBan(String tenPhongBan) {
        this.tenPhongBan = tenPhongBan;
    }
 
}
